# tests/fixtures

Reserved for tests / fixtures. Use synthetic or approved fixtures only.

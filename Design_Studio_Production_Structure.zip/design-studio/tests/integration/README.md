# tests/integration

Reserved for tests / integration. Use synthetic or approved fixtures only.

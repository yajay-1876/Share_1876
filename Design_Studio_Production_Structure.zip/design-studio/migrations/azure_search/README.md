# migrations/azure_search

Reserved for migrations / azure_search. Use synthetic or approved fixtures only.

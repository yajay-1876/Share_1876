# migrations/neo4j

Reserved for migrations / neo4j. Use synthetic or approved fixtures only.

# resources/schema_versions

Reserved for resources / schema_versions. Use synthetic or approved fixtures only.

# resources/validation_rules

Reserved for resources / validation_rules. Use synthetic or approved fixtures only.

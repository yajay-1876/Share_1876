# resources/mappings

Reserved for resources / mappings. Use synthetic or approved fixtures only.

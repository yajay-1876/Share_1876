# Design Studio — production-oriented folder structure

This is a proposed architecture scaffold for team review, not a working or production-ready application. Python modules are documented placeholders; external services, API routes, workers, security controls, tests and deployment pipelines are not implemented.

## Start here
1. Extract this ZIP and open the design-studio folder in VS Code.
2. Review FOLDER_STRUCTURE.txt and docs/architecture.md with the team.
3. Agree extraction output schemas and ingestion destination mappings.
4. Implement configuration, schemas, pipeline modules, adapters, logging and meaningful tests first.
5. Introduce API endpoints, queues, review workflows and deployment infrastructure when requirements are confirmed.

## Tooling
pyproject.toml is starter metadata only. Agree the Python version and approved dependencies before installation. Generate uv.lock using uv lock after dependencies are selected; no fabricated lockfile is supplied. Create .venv locally; it is intentionally excluded.

## Scope
Confirmed storage/search choices: Neo4j, Azure AI Search and PostgreSQL. Extraction clients, blob storage, queues and model providers are proposed integration points, subject to team confirmation. No credentials or client documents are included.

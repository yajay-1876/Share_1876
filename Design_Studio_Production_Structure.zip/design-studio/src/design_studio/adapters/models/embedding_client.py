"""adapters/models/embedding_client: reserved implementation module.

Architecture scaffold only; implement and review before production use.
"""

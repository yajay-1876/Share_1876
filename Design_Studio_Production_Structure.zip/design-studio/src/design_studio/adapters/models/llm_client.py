"""adapters/models/llm_client: reserved implementation module.

Architecture scaffold only; implement and review before production use.
"""

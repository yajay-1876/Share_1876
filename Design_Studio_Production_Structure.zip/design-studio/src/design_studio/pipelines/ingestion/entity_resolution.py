"""pipelines/ingestion/entity_resolution: reserved implementation module.

Architecture scaffold only; implement and review before production use.
"""

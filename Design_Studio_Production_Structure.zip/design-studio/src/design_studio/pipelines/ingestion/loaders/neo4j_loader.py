"""pipelines/ingestion/loaders/neo4j_loader: reserved implementation module.

Architecture scaffold only; implement and review before production use.
"""

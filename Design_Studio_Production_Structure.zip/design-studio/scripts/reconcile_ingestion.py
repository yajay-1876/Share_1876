"""Operational command placeholder; implementation pending."""

if __name__ == "__main__":
    raise SystemExit("Scaffold only: implement this command before running jobs.")

# Configuration

Use config/base.yaml plus one environment override. core/settings.py should validate required values and define override precedence. Never commit secrets. Use approved secret management and workload identities where supported.

# docs/decisions

Reserved for docs / decisions. Use synthetic or approved fixtures only.

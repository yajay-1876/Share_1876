# Architecture and responsibilities

- pipelines: orchestrate extraction and ingestion stages.
- schemas: versioned contracts between stages, not database connections.
- adapters: encapsulate external SDK calls and connection management.
- services: application actions such as submit, retry and review.
- repositories: persistence and queries for document, job and review records.
- loaders: transform canonical pipeline output into destination-specific records.
- workers: execute long-running jobs independently of HTTP requests.
- core: settings, structured logging, shared exceptions and security policies.
- observability: metrics, tracing and audit events.
- resources: mappings, business validation rules and schema versions.
- migrations: reviewed changes to database schemas, graph constraints and search indexes.
- evaluations: approved benchmark datasets and extraction/ingestion quality checks.

## Data flow
Submit document -> persist document/job metadata -> extraction -> validate canonical output -> optional human review -> ingestion transformations -> destination loaders -> reconcile destination status.

## Production design requirements
Carry document ID, source revision, page/location provenance, job ID and pipeline/schema versions. Use stable record identifiers and idempotent upserts. Persist stage checkpoints and intermediate artifact references. Track success separately for Neo4j, Azure AI Search and PostgreSQL: no atomic transaction is assumed across them. Retry transient failures with limits and backoff; route exhausted jobs to a failed/dead-letter state. Reconciliation must repair partial ingestion. Replacement/deletion must remove stale destination records.

Enforce document authorization, approved identity and secret management, log redaction, upload validation, retention rules and auditable review decisions. Define confidence thresholds and review behavior with stakeholders. Monitor throughput, queue backlog, latency, failures and model usage.

These requirements are design guidance; the scaffold does not implement them.

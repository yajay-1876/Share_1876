# Data Contracts

Agree document identity/revision, page and bounding-box provenance, extracted elements, confidence, warnings, schema version and artifact references. Job records need stage status, attempt count and per-destination outcomes. Define compatibility rules before changing schemas.

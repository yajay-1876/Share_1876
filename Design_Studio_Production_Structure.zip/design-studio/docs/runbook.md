# Runbook

Before release, document health/readiness checks, alerts, bounded retries, failed-job recovery, reconciliation, rollback, backup/restore, retention and incident ownership. Do not run placeholder scripts against real systems.

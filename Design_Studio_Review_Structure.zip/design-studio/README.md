# Design Studio — extraction and ingestion scaffold

Review proposal aligned with the request for a fresh, minimal folder structure with configuration and settings, designed to grow into production use.

## Status
This archive contains folders, documented placeholder modules and design guidance. It is not a working pipeline or production-ready application. No external services are contacted. No dependencies, credentials, model weights or client documents are bundled.

## Review
1. Extract the archive and open design-studio in VS Code.
2. Read FOLDER_STRUCTURE.txt and docs/architecture.md.
3. Agree document formats, extraction tools, data contracts and configuration conventions with Diksha.
4. Implement and validate the two pipelines incrementally.

## Responsibilities
- config/: non-secret processing options and logging configuration.
- core/: centralized settings loading, logging and exception definitions.
- schemas/: shared, versioned contracts between the pipelines.
- pipelines/extraction/: document-specific extraction and validation.
- pipelines/ingestion/: transformations, validation and destination loading.
- adapters/: external SDK calls and connections.
- resources/: domain mappings and validation rules.
- tests/: unit tests, integration tests and approved fixtures.

Neo4j, Azure AI Search and PostgreSQL are the confirmed destinations. Extraction adapter names are proposed integration points, pending team approval.

## Tooling
Python >=3.11 is provisional starter metadata; select a team-approved supported version. Add approved dependencies to pyproject.toml and generate the lockfile using the team's package manager. Create the virtual environment locally. Configuration loading, packaging and resource inclusion must be implemented before distribution.

No API, queue, worker, redaction or deployment framework is prescribed at this review stage. Add these when their responsibilities are confirmed.

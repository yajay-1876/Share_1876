"""Define application-specific exception types.

Design scaffold: implementation pending team review.
"""

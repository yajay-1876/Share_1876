"""Define the versioned extraction output contract.

Design scaffold: implementation pending team review.
"""

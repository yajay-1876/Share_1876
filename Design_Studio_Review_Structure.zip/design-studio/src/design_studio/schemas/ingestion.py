"""Define ingestion input and per-destination outcomes.

Design scaffold: implementation pending team review.
"""

"""Define document identity, revision, checksum and source provenance.

Design scaffold: implementation pending team review.
"""

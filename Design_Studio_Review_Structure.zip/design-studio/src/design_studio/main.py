"""Application entry point; orchestration is not implemented yet."""

def main():
    raise SystemExit("Design scaffold only: pipeline implementation pending.")

if __name__ == "__main__":
    main()

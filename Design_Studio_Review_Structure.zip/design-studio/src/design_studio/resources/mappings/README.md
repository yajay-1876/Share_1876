# mappings

Versioned domain field mappings.

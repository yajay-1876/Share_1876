"""Validate destination-ready records before writes.

Design scaffold: implementation pending team review.
"""

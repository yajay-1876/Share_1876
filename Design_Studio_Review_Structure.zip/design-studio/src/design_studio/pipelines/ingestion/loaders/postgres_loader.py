"""Map canonical data to relational records.

Design scaffold: implementation pending team review.
"""

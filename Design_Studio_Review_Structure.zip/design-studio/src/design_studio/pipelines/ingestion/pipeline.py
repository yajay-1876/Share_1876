"""Coordinate transformations, validation and destination loaders.

Design scaffold: implementation pending team review.
"""

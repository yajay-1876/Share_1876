"""Validate extracted output against the agreed contract.

Design scaffold: implementation pending team review.
"""

# fixtures

Synthetic or explicitly approved sample documents and expected results.

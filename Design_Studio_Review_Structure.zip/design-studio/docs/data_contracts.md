# Proposed data contracts — for review

## Document
Document ID, revision, source checksum, source reference, media type and relevant access/project scope.

## Extraction result
Document identity; schema and extraction version; extracted elements; source page/location; warnings and confidence where available; output artifact references. Agree coordinate conventions and confidence meaning before implementation.

## Ingestion result
Document revision; run ID; per-destination status; record counts/identifiers; error category; attempt/checkpoint information; created/updated timestamps.

## Decisions required
Agree required/optional fields, schema compatibility, extraction acceptance criteria, stable record keys, partial-failure handling and stale-record removal. If sanitization/review is required, define the approval evidence ingestion must verify.

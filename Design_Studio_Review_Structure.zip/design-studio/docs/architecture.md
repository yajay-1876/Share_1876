# Architecture

## Flow
Document input -> extraction pipeline -> validated extraction contract -> ingestion transformations -> validated destination records -> Neo4j / Azure AI Search / PostgreSQL loaders.

This expresses the proposed processing sequence, not implemented behavior.

## Boundaries
Pipeline modules coordinate business processing. Extraction modules use approved extraction adapters. Destination loaders decide which records to write; storage clients encapsulate connections and SDK/database operations. Schemas define the boundary between extraction and ingestion. Core settings validate configuration at startup.

Keep SDK types inside adapters where practical. Avoid circular dependencies and generic utility modules with unrelated responsibilities. Split document-specific modules into packages when multiple cohesive components are needed.

## Production requirements to implement
- Stable document IDs, revisions, checksums and deterministic destination record IDs.
- Source page/location provenance and schema/pipeline version tracking.
- Idempotent writes, bounded retries and explicit handling of permanent failures.
- Separate success/failure state for each destination; do not assume cross-store atomicity.
- Durable job/stage state, intermediate artifact references and recovery/reconciliation behavior. Agree persistence ownership before implementation.
- Replacement and deletion of stale records for superseded source revisions.
- Validated settings, approved secret management, access control and sensitive-content-safe logs.
- Regression tests on approved samples and integration tests at real system boundaries.

These are design requirements, not implemented capabilities.

## Runtime artifacts
Keep generated documents, logs, downloaded model weights and caches outside source code. Make their locations configurable; use approved durable storage where recovery requires it. Never use source folders as the production job database.

## Deferred decisions
Confirm execution method, review/redaction handoff, authentication, document authorization, retention, concurrency and deployment requirements with the team. Then add the required components without reorganizing extraction and ingestion.
